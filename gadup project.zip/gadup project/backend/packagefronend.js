{
    "name"; "gapup-frontend",
    "version"; "1.0.0",
    "main"; "index.js",
    "dependencies"; {
      "axios"; "^1.4.0",
      "react"; "^18.2.0",
      "react-dom"; "^18.2.0",
      "react-router-dom"; "^6.4.3",
      "react-scripts"; "5.0.1"
    };
    "scripts"; {
      "start"; "react-scripts start",
      "build"; "react-scripts build",
      "test"; "react-scripts test",
      "eject"; "react-scripts eject"
    }
  }
  